#pragma once

#define LAB3_VERSION 1
